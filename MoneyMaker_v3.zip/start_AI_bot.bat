@echo off
cd /d "D:\VisualStudioProjects\MoneyMaker"

rem Optional: hedging + rate limits here
set HEDGE_ENABLED=1
set HEDGE_RATIO=0.5
set HEDGE_TP_PCT=0.0020
set HEDGE_SL_PCT=0.0050
set HEDGE_COOLDOWN_SEC=120
set MAX_TRADES_PER_HOUR=6

python main.py --live-ai
pause
