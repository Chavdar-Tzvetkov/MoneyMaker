@echo off
setlocal
cd /d "D:\VisualStudioProjects\MoneyMaker"
set USE_META_DECIDER=0
python main.py --live
endlocal
pause
