﻿from __future__ import annotations

import os
import time
from typing import Optional, Dict, Tuple, Any, Callable, List

import requests

from strategies.sma_strategy import analyze_sma
from strategies.scalping_strategy import analyze_scalping
from strategies.strategy_config import ACTIVE_STRATEGY, switch_strategy_if_needed

from utils.market_data import get_last_price, load_recent_bars
from utils.market_hours import is_market_open
from utils.symbols import is_forex, normalize_symbol, to_mt5_symbol

from ai.meta_controller import MetaController  # AI decider (per-symbol, persistent)
from ai.llm_decider import llm_decide, combine_llm_with_quant  # <-- LLM layer

# Extra strategies wired for AI
from strategies.rsi_reversion import analyze_rsi
from strategies.donchian_breakout import analyze_donchian_breakout
from strategies.supertrend_trend import analyze_supertrend
from strategies.macd_trend import analyze_macd
from strategies.range_band_mr import analyze_range_mr  # NEW

from mt5_api import (
    get_current_price as mt5_get_price,
    place_market_order as mt5_place_order,
    get_position as mt5_get_position,
    close_position_market as mt5_close_position,
    modify_position_sl_tp as mt5_modify_sl_tp,
)

from trading212_api import (
    get_current_price as t212_get_price,  # currently unused (no REST price)
    place_market_order as t212_place_order,
    get_account_info,
    get_equity_position_qty,
    list_open_positions,
    reconcile_t212_portfolio_to_db,
    debug_dump_portfolio_map,
    invalidate_portfolio_cache,
)

from services.position_service import (
    get_position as db_get_position,
    upsert_position as db_update_position,
)

from config import (
    INSTRUMENTS, FOREX_SYMBOLS, TRADE_QUANTITY,
    TAKE_PROFIT_PERCENT, STOP_LOSS_PERCENT,
    MAX_POSITIONS_PER_SYMBOL, REENTRY_COOLDOWN_SEC, REENTRY_DELTA_PCT,
    TRAILING_STOP_ENABLED, TRAILING_STOP_DISTANCE_PCT, TRAILING_STEP_PCT, BREAKEVEN_AFTER_PCT,
    # Equity software stops/trailing
    EQUITY_STOPS_ENABLED, EQUITY_TAKE_PROFIT_PERCENT, EQUITY_STOP_LOSS_PERCENT,
    EQUITY_TRAILING_ENABLED, EQUITY_TRAILING_DISTANCE_PCT, EQUITY_TRAILING_STEP_PCT, EQUITY_BREAKEVEN_AFTER_PCT,
    # Spike-fade
    SPIKE_FADE_ENABLED, SPIKE_FADE_ATR_MULT, SPIKE_FADE_MIN_RET_PCT, SPIKE_FADE_COOLDOWN_SEC,
)

# ==============================================================================
# OpenAI logic toggles (environment)
# ==============================================================================
LLM_ENABLED = bool(int(os.getenv("LLM_ENABLED", "0")))
LLM_MODE = os.getenv("LLM_MODE", "TIE_BREAK").upper()  # TIE_BREAK | HARD_VETO | ENSEMBLE
LLM_MIN_CONF = float(os.getenv("LLM_MIN_CONF", "0.65"))

# =============================================================================
# Feature flags / limits
# =============================================================================
USE_META_DECIDER = bool(int(os.getenv("USE_META_DECIDER", "1")))          # AI on/off
MAX_TRADES_PER_HOUR = int(os.getenv("MAX_TRADES_PER_HOUR", "6"))          # per-symbol
MAX_ACCEPTABLE_UNCERTAINTY = float(os.getenv("MAX_ACCEPTABLE_UNCERTAINTY", "0.95"))

# =============================================================================
# Hedge settings (FX only; stocks not hedged here)
# =============================================================================
HEDGE_ENABLED = bool(int(os.getenv("HEDGE_ENABLED", "1")))
HEDGE_RATIO = float(os.getenv("HEDGE_RATIO", "0.5"))
HEDGE_TP_PCT = float(os.getenv("HEDGE_TP_PCT", "0.004"))
HEDGE_SL_PCT = float(os.getenv("HEDGE_SL_PCT", "0.004"))
HEDGE_COOLDOWN_SEC = float(os.getenv("HEDGE_COOLDOWN_SEC", "60"))

# Re-entry & pacing state
_last_entry: Dict[str, Dict] = {}        # symbol -> {"side":"LONG/SHORT", "price":float, "time":float}
_last_t212_order_ts: float = 0.0
T212_MIN_ORDER_INTERVAL_SEC = 1.2

# Track when we last opened a hedge per symbol to avoid rapid re-hedging
_last_hedge_open_ts: Dict[str, float] = {}

# Track when we last spike-flipped per symbol
_last_spike_flip_ts: Dict[str, float] = {}

# Per-symbol order timestamps for rate limiting
_order_times: Dict[str, List[float]] = {}

# Equity trailing state (software trailing on T212)
_eq_trail_sl: Dict[str, float] = {}      # symbol -> trailing stop price

# =============================================================================
# Strategy runners used by the AI decision
# =============================================================================
def _run_rsi(symbol: str, params: dict) -> Optional[str]:
    return analyze_rsi(
        symbol,
        lookback=params.get("lookback", "10d"),
        interval=params.get("interval", "15m"),
        rsi_len=int(params.get("rsi_len", 14)),
        overbought=float(params.get("overbought", 70.0)),
        oversold=float(params.get("oversold", 30.0)),
        trend_sma=int(params.get("trend_sma", 50)),
        buffer_bps=float(params.get("buffer_bps", 3.0)),
    )

def _run_donchian(symbol: str, params: dict) -> Optional[str]:
    return analyze_donchian_breakout(
        symbol,
        lookback=params.get("lookback", "20d"),
        interval=params.get("interval", "30m"),
        ch_len=int(params.get("ch_len", 20)),
        atr_len=int(params.get("atr_len", 14)),
        min_range_bps=float(params.get("min_range_bps", 12.0)),
        buffer_atr=float(params.get("buffer_atr", 0.25)),
    )

def _run_supertrend(symbol: str, params: dict) -> Optional[str]:
    return analyze_supertrend(
        symbol,
        lookback=params.get("lookback", "20d"),
        interval=params.get("interval", "15m"),
        atr_len=int(params.get("atr_len", 10)),
        mult=float(params.get("mult", 3.0)),
    )

def _run_macd(symbol: str, params: dict) -> Optional[str]:
    return analyze_macd(
        symbol,
        lookback=params.get("lookback", "20d"),
        interval=params.get("interval", "15m"),
        fast=int(params.get("fast", 12)),
        slow=int(params.get("slow", 26)),
        signal=int(params.get("signal", 9)),
        slope_len=int(params.get("slope_len", 50)),
    )

def _run_range_mr(symbol: str, params: dict):
    return analyze_range_mr(
        symbol,
        lookback=params.get("lookback", "3d"),
        interval=params.get("interval", "1m"),
        length=int(params.get("length", 60)),
        z_entry=float(params.get("z_entry", 1.2)),
        z_exit=float(params.get("z_exit", 0.2)),
        slope_thr=float(params.get("slope_thr", 0.0004)),
        min_bw=float(params.get("min_bw", 0.0008)),
        max_bw=float(params.get("max_bw", 0.0040)),
    )

STRATEGY_RUNNERS: Dict[str, Callable[[str, Dict[str, Any]], Optional[str]]] = {
    "SMA":       lambda s, p: analyze_sma(s),

    # Classic name used in config-driven mode
    "SCALPING":  lambda s, p: analyze_scalping(s),

    # Alias so the AI can call scalping as "SCALP"
    "SCALP":     lambda s, p: analyze_scalping(s),

    "RSI_MR":    _run_rsi,
    "DONCHIAN":  _run_donchian,
    "SUPER":     _run_supertrend,
    "MACD":      _run_macd,
    "RANGE_MR":  _run_range_mr,
    "HOLD":      lambda _s, _p: "HOLD",
}

# =============================================================================
# Routing and helpers
# =============================================================================
def _route_get_price(symbol: str) -> Optional[float]:
    """Price source routing: FX -> MT5 tick; Stocks -> local feed (yfinance)."""
    if is_forex(symbol):
        return mt5_get_price(to_mt5_symbol(symbol))
    return get_last_price(symbol)

def _route_open(symbol: str, quantity: float) -> Tuple[bool, str]:
    """Open a market order on the right venue."""
    global _last_t212_order_ts

    if is_forex(symbol):
        mt5_sym = to_mt5_symbol(symbol)
        tp = TAKE_PROFIT_PERCENT if TAKE_PROFIT_PERCENT and TAKE_PROFIT_PERCENT > 0 else None
        sl = abs(STOP_LOSS_PERCENT) if STOP_LOSS_PERCENT and STOP_LOSS_PERCENT < 0 else None
        return mt5_place_order(mt5_sym, quantity, tp_pct=tp, sl_pct=sl)

    # T212 equity order pacing to reduce 429 TooManyRequests
    now = time.time()
    delta = now - _last_t212_order_ts
    if delta < T212_MIN_ORDER_INTERVAL_SEC:
        time.sleep(T212_MIN_ORDER_INTERVAL_SEC - delta)

    ok = t212_place_order(symbol, quantity)
    _last_t212_order_ts = time.time()
    return (ok, "T212 order placed" if ok else "T212 order failed or not configured")

def _route_close(symbol: str) -> Tuple[bool, str]:
    """Close existing position: FX supported via MT5; equities close via negative market order."""
    if is_forex(symbol):
        return mt5_close_position(to_mt5_symbol(symbol))
    # For T212, we close by placing a negative quantity order elsewhere in the code.
    return (False, "T212 close handled by SELL order")

def _analyze_classic(symbol: str) -> Optional[str]:
    """Fallback to config-selected strategy when AI is disabled."""
    return analyze_sma(symbol) if ACTIVE_STRATEGY == "SMA" else analyze_scalping(symbol)

def _can_reenter(symbol: str, side: str, price: float) -> bool:
    info = _last_entry.get(symbol)
    if not info:
        return True
    if time.time() - info["time"] < REENTRY_COOLDOWN_SEC:
        return False
    delta = (price - info["price"]) / info["price"]
    return abs(delta) >= REENTRY_DELTA_PCT

def _remember_entry(symbol: str, side: str, price: float):
    _last_entry[symbol] = {"side": side, "price": price, "time": time.time()}

# ------------------------- FX trailing (broker-side) -------------------------
def _manage_trailing(symbol: str, price: float):
    """Breakeven and trailing stop only for FX (MT5). Non-blocking."""
    if not TRAILING_STOP_ENABLED or not is_forex(symbol):
        return
    mt5_sym = to_mt5_symbol(symbol)
    pos = mt5_get_position(mt5_sym)
    if not pos:
        return

    side = "LONG" if pos["type"] == 0 else "SHORT"
    entry = float(pos["price_open"])
    cur_sl = float(pos.get("sl", 0.0) or 0.0)

    pnl = (price - entry) / entry if side == "LONG" else (entry - price) / entry
    if pnl < BREAKEVEN_AFTER_PCT:
        return

    new_sl = max(entry, cur_sl) if side == "LONG" else min(entry, cur_sl if cur_sl else entry * 10)
    trail = TRAILING_STOP_DISTANCE_PCT
    candidate = (price - price * trail) if side == "LONG" else (price + price * trail)

    if side == "LONG":
        candidate = max(candidate, entry)
        if new_sl == 0.0 or candidate - new_sl >= price * TRAILING_STEP_PCT:
            new_sl = max(new_sl, candidate)
    else:
        candidate = min(candidate, entry)
        if new_sl == 0.0 or new_sl - candidate >= price * TRAILING_STEP_PCT:
            new_sl = min(new_sl if new_sl else candidate, candidate)

    if new_sl and (
        (side == "LONG" and (cur_sl == 0.0 or new_sl > cur_sl)) or
        (side == "SHORT" and (cur_sl == 0.0 or new_sl < cur_sl))
    ):
        ok, msg = mt5_modify_sl_tp(mt5_sym, sl=new_sl, tp=None)
        print(f"[TRAIL] {symbol}: {msg}")

# -------------------- Equity software stops / trailing -----------------------
def _equity_manage_soft_stops(symbol: str, price: float) -> bool:
    """
    Software TP/SL + breakeven/trailing for T212 equities.
    Returns True if we executed a sell-to-close (so caller should continue).
    """
    if not EQUITY_STOPS_ENABLED:
        return False

    qty_live = get_equity_position_qty(symbol) or 0.0
    if qty_live <= 0.0:
        _eq_trail_sl.pop(symbol, None)
        return False

    key = normalize_symbol(symbol)
    db_pos = db_get_position(key)
    entry = float(getattr(db_pos, "avg_price", 0.0) or 0.0)
    if entry <= 0.0:
        return False

    pnl = (price - entry) / entry

    # Hard TP / SL
    if EQUITY_TAKE_PROFIT_PERCENT and pnl >= EQUITY_TAKE_PROFIT_PERCENT:
        ok, info = _route_open(symbol, -qty_live)  # sell-to-close all
        print(f"[EQ TP] {symbol}: {info} @ pnl={pnl:.4f}")
        if ok:
            invalidate_portfolio_cache()
            db_update_position(key, 0.0, 0.0, overwrite=True)
            _eq_trail_sl.pop(symbol, None)
        return bool(ok)

    if EQUITY_STOP_LOSS_PERCENT and pnl <= EQUITY_STOP_LOSS_PERCENT:
        ok, info = _route_open(symbol, -qty_live)  # sell-to-close all
        print(f"[EQ SL] {symbol}: {info} @ pnl={pnl:.4f}")
        if ok:
            invalidate_portfolio_cache()
            db_update_position(key, 0.0, 0.0, overwrite=True)
            _eq_trail_sl.pop(symbol, None)
        return bool(ok)

    # Breakeven + trailing
    if not EQUITY_TRAILING_ENABLED:
        return False

    if pnl < EQUITY_BREAKEVEN_AFTER_PCT:
        return False

    # update trailing stop
    candidate = max(entry, price * (1.0 - EQUITY_TRAILING_DISTANCE_PCT))
    prev = _eq_trail_sl.get(symbol, entry)
    if candidate - prev >= price * EQUITY_TRAILING_STEP_PCT:
        _eq_trail_sl[symbol] = candidate
        if os.getenv("T212_DEBUG", "0") == "1":
            print(f"[EQ TRAIL] {symbol}: raise SL → {candidate:.4f}")

    # trigger trailing stop
    sl = _eq_trail_sl.get(symbol, None)
    if sl and price <= sl:
        ok, info = _route_open(symbol, -qty_live)
        print(f"[EQ TRAIL STOP] {symbol}: {info} | price={price:.4f} <= SL={sl:.4f}")
        if ok:
            invalidate_portfolio_cache()
            db_update_position(key, 0.0, 0.0, overwrite=True)
            _eq_trail_sl.pop(symbol, None)
        return bool(ok)

    return False

# =============================================================================
# Hedge controller (FX only)
# =============================================================================
def _maybe_hedge_fx(symbol: str, sma_trend: Optional[str]) -> None:
    if not HEDGE_ENABLED or not is_forex(symbol):
        return
    if sma_trend not in ("BUY", "SELL"):
        return

    mt5_sym = to_mt5_symbol(symbol)
    pos = mt5_get_position(mt5_sym)
    if not pos:
        return

    now = time.time()
    last_ts = _last_hedge_open_ts.get(symbol, 0.0)
    if now - last_ts < HEDGE_COOLDOWN_SEC:
        return

    pos_side = "BUY" if pos["type"] == 0 else "SELL"
    if pos_side == sma_trend:
        return

    vol = float(pos["volume"])
    if vol <= 0:
        return

    hedge_vol = max(0.0, round(vol * HEDGE_RATIO, 2))
    if hedge_vol <= 0:
        return

    qty = hedge_vol if sma_trend == "BUY" else -hedge_vol
    ok, msg = mt5_place_order(mt5_sym, qty, tp_pct=HEDGE_TP_PCT, sl_pct=HEDGE_SL_PCT)
    print(f"[HEDGE] {symbol}: {msg}")
    if ok:
        _last_hedge_open_ts[symbol] = now

# =============================================================================
# Lightweight reward (for AI learning) + helper used by spike-fade
# =============================================================================
def _atr_percent(df, n: int = 14) -> float:
    try:
        h = df["High"].astype(float)
        l = df["Low"].astype(float)
        c = df["Close"].astype(float)
        prev_c = c.shift(1)
        tr = (h - l).abs().combine((h - prev_c).abs(), max).combine((l - prev_c).abs(), max)
        atr = tr.rolling(n).mean().iloc[-1]
        last_c = float(c.iloc[-1])
        if last_c > 0 and atr is not None:
            return float(atr) / last_c
    except Exception:
        pass
    try:
        c = df["Close"].astype(float)
        if len(c) > 5 and float(c.iloc[-1]) != 0.0:
            return float(c.pct_change().rolling(20).std().iloc[-1] or 0.0)
    except Exception:
        pass
    return 0.0

def _estimate_reward(df, outcome: Optional[str]) -> float:
    if outcome is None:
        return -0.05
    try:
        c = df["Close"].astype(float)
        if len(c) < 3:
            return 0.0
        ret = (float(c.iloc[-1]) - float(c.iloc[-2])) / max(float(c.iloc[-2]), 1e-12)
        atrp = _atr_percent(df)
        scale = atrp if atrp > 1e-6 else 1.0
        base = ret / scale
        if outcome == "BUY":
            r = base
        elif outcome == "SELL":
            r = -base
        elif outcome == "HOLD":
            r = -abs(base) * 0.1
        else:
            r = 0.0
        return float(max(-1.0, min(1.0, r)))
    except Exception:
        return 0.0

# --------------------------- Spike-fade overlay ------------------------------
def _spike_fade_adjust(symbol: str, df, outcome: Optional[str]) -> Optional[str]:
    """
    If SPIKE_FADE_ENABLED, and the last bar's absolute return is big relative to ATR%
    and above a fixed floor, flip BUY<->SELL once per cooldown window.
    """
    if not SPIKE_FADE_ENABLED or outcome not in ("BUY", "SELL"):
        return outcome
    if df is None or df.empty or "Close" not in df.columns or len(df) < 3:
        return outcome

    try:
        c = df["Close"].astype(float)
        last = float(c.iloc[-1])
        prev = float(c.iloc[-2]) if float(c.iloc[-2]) != 0.0 else last
        ret = (last - prev) / max(prev, 1e-12)           # last 1-bar return
        atrp = _atr_percent(df)                          # ATR as percent of price

        big_move = abs(ret) >= max(SPIKE_FADE_MIN_RET_PCT, SPIKE_FADE_ATR_MULT * atrp)

        now = time.time()
        last_ts = _last_spike_flip_ts.get(symbol, 0.0)
        cooled = (now - last_ts) >= SPIKE_FADE_COOLDOWN_SEC

        # only flip when AI/strategy is trying to go WITH the spike direction
        if big_move and cooled:
            if (ret > 0 and outcome == "BUY") or (ret < 0 and outcome == "SELL"):
                flipped = "SELL" if outcome == "BUY" else "BUY"
                _last_spike_flip_ts[symbol] = now
                print(f"[SPIKE-FADE] {symbol}: last_ret={ret:.4f}, atr%={atrp:.4f} "
                      f"=> flip {outcome}→{flipped}")
                return flipped
    except Exception as _:
        pass

    return outcome

# =============================================================================
# Rate limiting (per symbol)
# =============================================================================
def _rate_limit_ok(symbol: str) -> bool:
    now = time.time()
    window = 3600.0
    q = _order_times.setdefault(symbol, [])
    while q and (now - q[0]) > window:
        q.pop(0)
    return len(q) < MAX_TRADES_PER_HOUR

def _rate_mark(symbol: str) -> None:
    _order_times.setdefault(symbol, []).append(time.time())


def _current_position_qty(symbol: str) -> float:
    """
    LIVE exposure:
      - FX -> MT5 open positions (authoritative)
      - Stocks -> T212 portfolio (cached, authoritative)
    Positive -> long, Negative -> short, 0 -> flat.
    """
    if is_forex(symbol):
        mt5_sym = to_mt5_symbol(symbol)
        mtp = mt5_get_position(mt5_sym)
        if not mtp:
            return 0.0
        vol = float(mtp["volume"])
        return vol if mtp["type"] == 0 else -vol  # buy=0 -> +, sell=1 -> -
    else:
        return float(get_equity_position_qty(symbol) or 0.0)

# =============================================================================
# Main loop
# =============================================================================

def run_live_trading():
    print("\n==================================================")
    print(f"Starting trading cycle ({'AI' if USE_META_DECIDER else 'classic'}) with {ACTIVE_STRATEGY} default")
    all_symbols = list(FOREX_SYMBOLS) + list(INSTRUMENTS)  # track all equities, no slice
    print(f"Tracking {len(all_symbols)} symbols")
    print("==================================================\n")

    # One-time T212 account probe (and full equity reconciliation)
    try:
        acct = get_account_info()
        print("[T212] Account OK" if acct else "[T212] Account info not available.")

        try:
            updated, skipped = reconcile_t212_portfolio_to_db(force_refresh=True)
            print(f"[T212 RECON] DB updated for {updated} equity symbols (skipped {skipped}).")
        except Exception as e:
            print(f"[T212 RECON] Failed: {e}")

        try:
            debug_dump_portfolio_map()
            pos = list_open_positions() or []
            tickers = [f"{p.get('ticker')}={p.get('quantity')}" for p in pos]
            print(f"[T212 RAW] {len(pos)} items → " + ", ".join(tickers))
        except Exception as e:
            print(f"[T212 RAW] failed to fetch: {e}")

    except Exception as e:
        print(f"[T212] Skipping account info due to error: {e}")

    # Instantiate AI decider
    meta = MetaController(
        alpha=0.6, d=10,
        min_ucb_margin=float(os.getenv("AI_MIN_UCB_MARGIN", "0.00")),
        ucb_floor=float(os.getenv("AI_UCB_FLOOR", "-1.00")),
        flip_cooldown_sec=int(os.getenv("AI_FLIP_COOLDOWN_SEC", "60")),
    )

    while True:
        try:
            # ---------------------------
            # Auto-reconciliation pass
            # ---------------------------
            for symbol in all_symbols:
                try:
                    key = normalize_symbol(symbol)

                    live_qty = _current_position_qty(symbol)
                    db_pos = db_get_position(key)
                    db_qty = float(db_pos.quantity) if db_pos else 0.0

                    if live_qty != db_qty:
                        print(f"[RECON] {symbol}: DB={db_qty} → LIVE={live_qty} — syncing.")
                        price = 0.0 if live_qty == 0.0 else (_route_get_price(symbol) or 0.0)
                        db_update_position(key, live_qty, price, overwrite=True)

                        # reset re-entry gate when live position is flat (manual/TP/SL)
                        if live_qty == 0.0 and _last_entry.get(key):
                            _last_entry.pop(key, None)
                            _eq_trail_sl.pop(symbol, None)
                            print(f"[REENTRY RESET] {symbol}: flat live position → cooldown cleared.")

                except Exception as rec_err:
                    print(f"[RECON ERROR] {symbol}: {rec_err}")

            # Strategy switch (based on DailyPnL rule)
            switch_strategy_if_needed()

            # ---------------------------
            # Trading pass
            # ---------------------------
            for symbol in all_symbols:
                try:
                    if not is_market_open(symbol):
                        continue

                    price = _route_get_price(symbol)
                    if price is None:
                        continue

                    # Manage stops/trailing for FX and equities
                    _manage_trailing(symbol, price)               # FX trailing (broker-side)
                    if not is_forex(symbol) and _equity_manage_soft_stops(symbol, price):
                        # we already executed a sell-to-close via software stops; skip further logic
                        continue

                    # ======= Decision: AI or classic =======
                    decision_action = None
                    decision_strategy = None
                    decision_params: Dict[str, Any] = {}
                    decision_uncertainty = 0.0
                    outcome = None
                    df = None  # we might need it for spike-fade and LLM

                    if USE_META_DECIDER:
                        df = load_recent_bars(symbol, lookback="2d", interval="5m")
                        if df is None or df.empty:
                            outcome = _analyze_classic(symbol)
                        else:
                            md = meta.decide(df, symbol=symbol)
                            decision_action = md.action
                            decision_strategy = md.strategy
                            decision_params = md.params or {}
                            decision_uncertainty = md.uncertainty

                            if decision_strategy == "HOLD" or decision_uncertainty > MAX_ACCEPTABLE_UNCERTAINTY:
                                outcome = "HOLD"
                            else:
                                runner = STRATEGY_RUNNERS.get(decision_strategy, STRATEGY_RUNNERS["HOLD"])
                                outcome = runner(symbol, decision_params)

                            reward = _estimate_reward(df, outcome)
                            meta.learn(df, decision_action, reward, symbol=symbol)

                            print(f"[AI] {symbol} → strat={decision_strategy} params={decision_params} "
                                  f"u={decision_uncertainty:.2f} ⇒ {outcome}")
                    else:
                        outcome = _analyze_classic(symbol)

                    # ---- LLM tie-break / veto (optional) ----
                    if LLM_ENABLED:
                        if df is None:
                            df = load_recent_bars(symbol, lookback="2d", interval="5m")
                        if df is not None and not df.empty:
                            quant_hint = {
                                "quant_outcome": outcome,
                                "strategy": decision_strategy,
                                "uncertainty": decision_uncertainty,
                            }
                            llm_suggestion = llm_decide(symbol, df, candidate_from_quant=quant_hint)
                            if llm_suggestion:
                                prev = outcome
                                outcome = combine_llm_with_quant(prev, llm_suggestion, mode=LLM_MODE, min_conf=LLM_MIN_CONF)
                                if outcome == "HOLD":
                                    print(f"[LLM] {symbol}: veto/tie-break → HOLD "
                                          f"(conf={llm_suggestion.get('confidence'):.2f}, prev={prev})")
                                else:
                                    print(f"[LLM] {symbol}: allows {outcome} "
                                          f"(conf={llm_suggestion.get('confidence'):.2f}, prev={prev})")

                    # ---- Spike-fade overlay (optional) ----
                    if SPIKE_FADE_ENABLED and outcome in ("BUY", "SELL"):
                        if df is None:
                            df = load_recent_bars(symbol, lookback="1d", interval="5m")
                        outcome = _spike_fade_adjust(symbol, df, outcome)

                    if not outcome or outcome == "HOLD":
                        continue

                    cur_qty = _current_position_qty(symbol)
                    qty = float(TRADE_QUANTITY)
                    key = normalize_symbol(symbol)

                    db_pos = db_get_position(key)
                    db_qty = float(db_pos.quantity) if db_pos else 0.0
                    print(f"[POSCHK] {symbol}: LIVE={cur_qty} (src={'MT5' if is_forex(symbol) else 'T212'}) | DB={db_qty} | outcome={outcome}"
                          f"{'' if not USE_META_DECIDER else f' | AI={decision_action}/{decision_strategy} u={decision_uncertainty:.2f}'}")

                    # stacking guard
                    if MAX_POSITIONS_PER_SYMBOL > 0:
                        if outcome == "BUY" and cur_qty > 0.0:
                            print(f"[IN-POSITION] {symbol}: already long {cur_qty}, skipping buy.")
                            continue
                        if outcome == "SELL" and cur_qty < 0.0:
                            print(f"[IN-POSITION] {symbol}: already short {cur_qty}, skipping sell.")
                            continue

                    if not _rate_limit_ok(key):
                        print(f"[RATE] {symbol}: trades/hour limit reached, holding.")
                        continue

                    side = "LONG" if outcome == "BUY" else "SHORT"
                    if not _can_reenter(key, side, price):
                        print(f"[REENTRY] {symbol}: blocked (cooldown/distance).")
                        continue

                    print(f"[DECISION] {symbol}: {outcome} @ {price} | current_pos={cur_qty}")

                    # ---- Execute decision ----
                    if outcome == "BUY":
                        if is_forex(symbol):
                            if cur_qty < 0.0:
                                okc, infoc = _route_close(symbol)
                                print(f"[FLIP CLOSE] {symbol}: {infoc}")
                                if okc:
                                    db_update_position(key, +abs(cur_qty), price)
                            ok, info = _route_open(symbol, qty)
                            print(f"[ORDER] {symbol}: {info}")
                            if ok:
                                _rate_mark(key)
                                db_update_position(key, +qty, price)
                                _remember_entry(key, "LONG", price)
                        else:
                            ok, info = _route_open(symbol, qty)
                            print(f"[ORDER] {symbol}: {info}")
                            if ok:
                                _rate_mark(key)
                                invalidate_portfolio_cache()
                                db_update_position(key, +qty, price)
                                _remember_entry(key, "LONG", price)
                                # initialize equity trail anchor
                                _eq_trail_sl.pop(symbol, None)

                    elif outcome == "SELL":
                        if is_forex(symbol):
                            if cur_qty > 0.0:
                                okc, infoc = _route_close(symbol)
                                print(f"[FLIP CLOSE] {symbol}: {infoc}")
                                if okc:
                                    db_update_position(key, -abs(cur_qty), price)
                            ok, info = _route_open(symbol, -qty)
                            print(f"[ORDER] {symbol}: {info}")
                            if ok:
                                _rate_mark(key)
                                db_update_position(key, -qty, price)
                                _remember_entry(key, "SHORT", price)
                        else:
                            # Stocks: SELL == sell-to-close (no shorting). Close full position if any.
                            if cur_qty <= 0.0:
                                print("[EQUITY] Short selling blocked or no holdings to reduce.")
                                continue
                            sell_qty = cur_qty  # close all on SELL signal
                            ok, info = _route_open(symbol, -sell_qty)
                            print(f"[EQUITY CLOSE] {symbol}: {info}")
                            if ok:
                                _rate_mark(key)
                                invalidate_portfolio_cache()
                                db_update_position(key, 0.0, 0.0, overwrite=True)
                                _eq_trail_sl.pop(symbol, None)

                    # Optional FX hedge driven by SMA trend (independent of AI strategy)
                    sma_trend = analyze_sma(symbol) if is_forex(symbol) else None
                    _maybe_hedge_fx(symbol, sma_trend)

                except KeyboardInterrupt:
                    raise
                except Exception as sym_err:
                    print(f"[LOOP ERROR] {symbol}: {sym_err}")

            time.sleep(3)

        except KeyboardInterrupt:
            print("\n[STOP] Keyboard interrupt received. Exiting loop.")
            break
        except Exception as e:
            print(f"[FATAL LOOP ERROR] {e}")
            time.sleep(5)
