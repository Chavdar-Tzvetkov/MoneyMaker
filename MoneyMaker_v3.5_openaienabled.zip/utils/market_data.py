﻿# utils/market_data.py
from __future__ import annotations

import time
from typing import Optional
import pandas as pd
import yfinance as yf

from utils.symbols import to_yf_symbol

REQUIRED = ("Open", "High", "Low", "Close")


def _normalize_ohlc_columns(df: pd.DataFrame) -> Optional[pd.DataFrame]:
    """
    Take any yfinance frame (single or MultiIndex columns) and return a frame
    with columns exactly ['Open','High','Low','Close'] if possible.
    Fallback: if only 'Adj Close' exists, duplicate it to build OHLC.
    Returns None if we can't build a valid OHLC view.
    """
    if df is None or df.empty:
        return None

    # If MultiIndex columns, try to select the OHLC level
    if isinstance(df.columns, pd.MultiIndex):
        # Common case: ('AAPL','Open') -> take the last level
        last = set(df.columns.get_level_values(-1))
        first = set(df.columns.get_level_values(0))

        if set(REQUIRED).issubset(last):
            df = df.copy()
            df.columns = df.columns.get_level_values(-1)
        elif set(REQUIRED).issubset(first):
            df = df.copy()
            df.columns = df.columns.get_level_values(0)
        else:
            # Flatten tuples by picking the OHLC label if present
            new_cols = []
            for col in df.columns:
                if isinstance(col, tuple):
                    if "Open" in col:
                        new_cols.append("Open")
                    elif "High" in col:
                        new_cols.append("High")
                    elif "Low" in col:
                        new_cols.append("Low")
                    elif "Close" in col:
                        new_cols.append("Close")
                    elif "Adj Close" in col:
                        new_cols.append("Adj Close")
                    else:
                        new_cols.append(col[-1])
                else:
                    new_cols.append(col)
            df = df.copy()
            df.columns = new_cols

    # Normalize case (some envs return lower-case)
    rename_map = {}
    for c in df.columns:
        cl = str(c).strip().lower()
        if cl == "open":
            rename_map[c] = "Open"
        elif cl == "high":
            rename_map[c] = "High"
        elif cl == "low":
            rename_map[c] = "Low"
        elif cl == "close":
            rename_map[c] = "Close"
        elif cl in ("adj close", "adj_close", "adjusted close"):
            rename_map[c] = "Adj Close"
    if rename_map:
        df = df.rename(columns=rename_map)

    cols = set(df.columns)

    # If we have Adj Close only, synthesize OHLC from it
    if "Close" not in cols and "Adj Close" in cols:
        df = df.copy()
        df["Close"] = df["Adj Close"]

    # If some OHLC missing but Close exists, duplicate Close to fill gaps
    if "Close" in df.columns:
        for c in REQUIRED:
            if c not in df.columns:
                df[c] = df["Close"]

    # Final check: do we have the four we need?
    if not set(REQUIRED).issubset(df.columns):
        return None

    out = df.loc[:, list(REQUIRED)].dropna()
    return out if not out.empty else None


def load_recent_bars(symbol: str, lookback: str = "2d", interval: str = "5m") -> Optional[pd.DataFrame]:
    """
    Fetch recent OHLC bars for intraday strategies/scalping.
    Returns a DataFrame with exactly ['Open','High','Low','Close'] or None.
    """
    try:
        yf_sym = to_yf_symbol(symbol)
        df = yf.download(
            yf_sym,
            period=lookback,
            interval=interval,
            prepost=True,
            progress=False,
            auto_adjust=False,
            group_by="column",  # avoid MultiIndex where possible
        )
        df = _normalize_ohlc_columns(df)
        return df
    except Exception as e:
        print(f"[DATA ERROR] load_recent_bars {symbol}: {e}")
        return None


def get_clean_data(symbol: str, days: int = 90) -> Optional[pd.DataFrame]:
    """
    Download and validate close prices for SMA. Returns DF with ['Close'] or None.
    Retries a few times because yfinance can be flaky.
    """
    max_retries = 3

    for attempt in range(max_retries):
        try:
            yf_sym = to_yf_symbol(symbol)
            df = yf.download(
                yf_sym,
                period=f"{days}d",
                prepost=True,
                progress=False,
                auto_adjust=False,
                group_by="column",
            )
            if df is None or df.empty:
                raise ValueError("Empty dataframe")

            df = _normalize_ohlc_columns(df)
            if df is None or df.empty:
                raise ValueError("Cannot normalize OHLC")

            close = df[["Close"]].dropna()
            if len(close) < 50:
                raise ValueError("Insufficient data (<50 bars)")

            return close

        except Exception as e:
            print(f"[DATA ERROR] {symbol} attempt {attempt+1}: {e}")
            time.sleep(2)

    return None


def get_last_price(symbol: str) -> Optional[float]:
    """
    Lightweight last price (stocks/FX) using yfinance intraday.
    """
    try:
        yf_sym = to_yf_symbol(symbol)
        df = yf.download(
            yf_sym,
            period="1d",
            interval="1m",
            prepost=True,
            progress=False,
            auto_adjust=False,
            group_by="column",
        )
        df = _normalize_ohlc_columns(df)
        if df is not None and not df.empty and "Close" in df.columns:
            return float(df["Close"].iloc[-1])
    except Exception as e:
        print(f"[DATA ERROR] last price {symbol}: {e}")
    return None
